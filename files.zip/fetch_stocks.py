"""
fetch_stocks.py
===============
Fetches stock price history from Yahoo Finance and writes stocks_live.json
alongside your signals_live.json. The MortgageIQ dashboard reads this file
first before trying any CORS proxy, so the analyzer works reliably on both
localhost and a server deployment.

Usage:
    python3 fetch_stocks.py                    # fetch default universe
    python3 fetch_stocks.py NVDA MU TSLA MP    # fetch specific tickers
    python3 fetch_stocks.py --days 252         # 12 months of history

Add to cron (same job as pipeline.py):
    30 6 * * 1-5 python3 /path/to/fetch_stocks.py >> pipeline.log 2>&1
"""

import json
import sys
import time
import logging
import argparse
import urllib.request
import urllib.parse
from datetime import datetime, timedelta
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)-8s  %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("fetch_stocks")

OUTPUT_JSON = Path(__file__).parent / "stocks_live.json"

# Default universe — semiconductors + EV + mortgage originators
DEFAULT_TICKERS = [
    # Semiconductors / supply chain
    "NVDA", "MU", "AMD", "TSM", "AMAT", "LRCX", "KLAC", "ASML", "INTC", "QCOM",
    # Memory / storage
    "WD", "STX",
    # Rare earth / materials
    "MP", "ALB", "LAC",
    # EV
    "TSLA", "F", "GM", "RIVN",
    # Mortgage originators
    "RKT", "PFSI", "UWMC", "GHLD",
]

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9",
    "Origin": "https://finance.yahoo.com",
    "Referer": "https://finance.yahoo.com/",
}


def fetch_ticker(ticker: str, days: int = 252) -> list[dict]:
    """Fetch daily close prices from Yahoo Finance."""
    end   = int(datetime.now().timestamp())
    start = int((datetime.now() - timedelta(days=days + 30)).timestamp())

    # Try query1 then query2
    for host in ["query1", "query2"]:
        url = (f"https://{host}.finance.yahoo.com/v8/finance/chart/{ticker}"
               f"?interval=1d&period1={start}&period2={end}&events=history")
        try:
            req  = urllib.request.Request(url, headers=HEADERS)
            with urllib.request.urlopen(req, timeout=12) as resp:
                data = json.loads(resp.read())

            chart = data["chart"]
            if chart.get("error"):
                continue
            result     = chart["result"][0]
            timestamps = result["timestamp"]
            closes     = result["indicators"]["quote"][0]["close"]

            series = []
            for i, ts in enumerate(timestamps):
                if closes[i] is not None:
                    series.append({
                        "date":  datetime.fromtimestamp(ts).strftime("%Y-%m-%d"),
                        "price": round(closes[i], 4)
                    })

            trimmed = series[-days:]
            log.info(f"  {ticker:<6}  {len(trimmed):>3} days  last={trimmed[-1]['price'] if trimmed else '?'}")
            return trimmed

        except urllib.error.HTTPError as e:
            if e.code == 404:
                log.warning(f"  {ticker:<6}  404 — ticker not found")
                return []
            log.debug(f"  {ticker:<6}  HTTP {e.code} on {host}, trying next…")
        except Exception as e:
            log.debug(f"  {ticker:<6}  {host} error: {e}")
        time.sleep(0.3)

    log.warning(f"  {ticker:<6}  Failed on all hosts")
    return []


def main():
    parser = argparse.ArgumentParser(description="Fetch stock prices for MortgageIQ dashboard")
    parser.add_argument("tickers", nargs="*", help="Tickers to fetch (default: full universe)")
    parser.add_argument("--days",   type=int, default=504, help="Days of history (default 504 = 2 years)")
    parser.add_argument("--output", default=str(OUTPUT_JSON), help="Output JSON path")
    args = parser.parse_args()

    tickers = [t.upper() for t in args.tickers] if args.tickers else DEFAULT_TICKERS
    output  = Path(args.output)

    # Load existing data to merge (don't wipe on failure)
    existing = {}
    if output.exists():
        try:
            existing = json.loads(output.read_text())
        except Exception:
            pass

    log.info(f"Fetching {len(tickers)} tickers  →  {output}")

    result = dict(existing)
    ok, fail = 0, 0

    for ticker in tickers:
        series = fetch_ticker(ticker, args.days)
        if series:
            result[ticker] = series
            ok += 1
        else:
            fail += 1
        time.sleep(0.4)   # polite rate limiting

    result["_meta"] = {
        "fetched_at":   datetime.utcnow().isoformat() + "Z",
        "ticker_count": len([k for k in result if not k.startswith("_")]),
        "days":         args.days,
    }

    output.write_text(json.dumps(result, separators=(",", ":")))
    log.info(f"Done — {ok} OK, {fail} failed → {output}")


if __name__ == "__main__":
    main()
